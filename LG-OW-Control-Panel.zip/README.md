# LG OW — Guild Statistics Control Panel

A deployable starter project with:
- Vercel-ready static frontend
- Render-ready Node.js/Express API
- PostgreSQL persistence
- Guild profile and Glory-stat tracking
- Daily contribution records and server health status

**Important:** This is a guild-management/statistics dashboard. It does not play Free Fire,
control game clients, automate matches, or farm Glory. Add statistics manually or through
officially permitted data sources.

## 1. Deploy the database
Create a PostgreSQL database (Render PostgreSQL or another hosted PostgreSQL provider).
Copy its connection string (`DATABASE_URL`). Keep it private.

## 2. Deploy backend on Render
1. Push this folder to a GitHub repository.
2. In Render, create **New > Web Service** and select the repository.
3. Set **Root Directory** to `backend`.
4. Build command: `npm install`
5. Start command: `npm start`
6. Add environment variables:
   - `DATABASE_URL` = your PostgreSQL connection string
   - `ADMIN_TOKEN` = a long random secret
   - `FRONTEND_ORIGIN` = your Vercel site URL (after frontend deployment; initially you can use `*` for testing)
   - `NODE_ENV` = `production`
7. Deploy. Test `https://YOUR-API.onrender.com/api/health`.

## 3. Deploy frontend on Vercel
1. Import the same GitHub repository in Vercel.
2. Set **Root Directory** to `frontend`.
3. Framework preset: Other.
4. Build command: leave empty.
5. Output directory: `.`
6. Deploy.

## 4. Connect frontend to backend
Open `frontend/config.js` and replace `https://YOUR-RENDER-SERVICE.onrender.com`
with your real Render backend URL. Commit the change; Vercel will redeploy.
Then set the backend's `FRONTEND_ORIGIN` to your exact Vercel URL and redeploy backend.

## 5. Use the panel
- Open the Vercel URL.
- Use **Guild Settings** to save guild name, guild UID, and region.
- To add Glory records, enter the ADMIN_TOKEN configured on Render when prompted.
  The token is held only in the current page session and is not saved to local storage.
- Glory entries are records for tracking; they do not change anything inside Free Fire.

## API endpoints
- `GET /api/health`
- `GET /api/guild`
- `PUT /api/guild` (requires `x-admin-token`)
- `GET /api/glory?limit=30`
- `POST /api/glory` (requires `x-admin-token`)

## Security notes
- Never put `ADMIN_TOKEN` or `DATABASE_URL` in frontend files or screenshots.
- Use a unique, long admin token and do not share it.
- This starter does not connect to Garena or access player accounts.
