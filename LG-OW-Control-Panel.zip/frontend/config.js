// Replace this with your deployed Render backend URL.
window.LGOW_API_BASE = "https://YOUR-RENDER-SERVICE.onrender.com";
