const API = (window.LGOW_API_BASE || "").replace(/\/$/, "");
const $ = id => document.getElementById(id);
let adminToken = "";

function message(text, bad=false) {
  $("message").textContent = text;
  $("message").style.color = bad ? "#ff8a8a" : "#00c8ff";
}
async function api(path, options={}) {
  if (!API || API.includes("YOUR-RENDER-SERVICE")) throw new Error("Set your Render API URL in frontend/config.js first.");
  const headers = { "Content-Type":"application/json", ...(options.headers || {}) };
  const response = await fetch(API + path, {...options, headers});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function fmt(value){return Number(value || 0).toLocaleString("en-IN")}
async function loadHealth(){
  try{
    const h=await api("/api/health");
    $("serverStatus").textContent="SERVER ONLINE";$("statusDot").parentElement.classList.add("online");
    $("apiStatus").textContent="ONLINE";$("apiTime").textContent="Database connected";
  }catch(e){
    $("serverStatus").textContent="SERVER OFFLINE";$("statusDot").parentElement.classList.remove("online");
    $("apiStatus").textContent="OFFLINE";$("apiTime").textContent=e.message;
  }
}
async function loadGuild(){
  try{
    const g=await api("/api/guild");
    $("guildName").value=g.guild_name||"";$("guildUid").value=g.guild_uid||"";$("region").value=g.region||"India";
    $("heroRegion").textContent=(g.region||"India").toUpperCase();
  }catch(e){message(e.message,true)}
}
async function loadGlory(){
  try{
    const data=await api("/api/glory?limit=30");
    $("totalGlory").textContent=fmt(data.total_glory);$("entryCount").textContent=fmt(data.entries.length);
    $("records").innerHTML="";
    if(!data.entries.length){$("records").innerHTML='<tr><td colspan="4" class="empty">No records yet. Add your first entry.</td></tr>';return}
    for(const item of data.entries){
      const tr=document.createElement("tr");
      const values=[item.member_name,item.member_uid||"—",fmt(item.glory),new Date(item.created_at).toLocaleString()];
      values.forEach((v,i)=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td)});
      $("records").appendChild(tr);
    }
  }catch(e){$("records").innerHTML='<tr><td colspan="4" class="empty">Could not load records.</td></tr>';message(e.message,true)}
}
$("adminToken").onclick=()=>{
  const token=prompt("Enter the ADMIN_TOKEN configured on your Render backend. It will stay only in this page session.");
  if(token!==null){adminToken=token.trim();message(adminToken?"Admin token set for this session.":"Admin token cleared.");}
};
$("saveGuild").onclick=async()=>{
  if(!adminToken)return message("Set the admin token first.",true);
  try{
    const g=await api("/api/guild",{method:"PUT",headers:{"x-admin-token":adminToken},
      body:JSON.stringify({guild_name:$("guildName").value,guild_uid:$("guildUid").value,region:$("region").value})});
    $("heroRegion").textContent=g.region.toUpperCase();message("Guild settings saved.");
  }catch(e){message(e.message,true)}
};
$("addEntry").onclick=async()=>{
  if(!adminToken)return message("Set the admin token first.",true);
  try{
    await api("/api/glory",{method:"POST",headers:{"x-admin-token":adminToken},
      body:JSON.stringify({member_name:$("memberName").value,member_uid:$("memberUid").value,
        glory:Number($("glory").value),note:$("note").value})});
    $("memberName").value="";$("memberUid").value="";$("glory").value="";$("note").value="";
    message("Glory record saved.");await loadGlory();
  }catch(e){message(e.message,true)}
};
$("refresh").onclick=async()=>{await Promise.all([loadHealth(),loadGlory(),loadGuild()]);message("Dashboard refreshed.");};
(async()=>{await Promise.all([loadHealth(),loadGuild(),loadGlory()]);})();
