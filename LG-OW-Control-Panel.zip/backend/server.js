const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
app.use(express.json({ limit: "32kb" }));

const allowedOrigin = process.env.FRONTEND_ORIGIN || "*";
app.use(cors({
  origin: allowedOrigin === "*" ? true : allowedOrigin.split(",").map(s => s.trim()),
  methods: ["GET", "POST", "PUT", "OPTIONS"],
  allowedHeaders: ["Content-Type", "x-admin-token"]
}));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes("localhost")
    ? { rejectUnauthorized: false } : false
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS guild (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      guild_name TEXT NOT NULL DEFAULT 'LG OW',
      guild_uid TEXT NOT NULL DEFAULT '',
      region TEXT NOT NULL DEFAULT 'India',
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    INSERT INTO guild (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
    CREATE TABLE IF NOT EXISTS glory_entries (
      id BIGSERIAL PRIMARY KEY,
      member_name TEXT NOT NULL,
      member_uid TEXT NOT NULL DEFAULT '',
      glory INTEGER NOT NULL CHECK (glory >= 0),
      note TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

function requireAdmin(req, res, next) {
  const expected = process.env.ADMIN_TOKEN;
  if (!expected) return res.status(503).json({ error: "ADMIN_TOKEN is not configured on the server." });
  if (req.get("x-admin-token") !== expected) {
    return res.status(401).json({ error: "Admin token is missing or incorrect." });
  }
  next();
}

app.get("/api/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", service: "LG OW API", database: "connected", time: new Date().toISOString() });
  } catch {
    res.status(503).json({ status: "error", database: "unavailable" });
  }
});

app.get("/api/guild", async (_req, res) => {
  try {
    const result = await pool.query("SELECT guild_name, guild_uid, region, updated_at FROM guild WHERE id=1");
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: "Could not load guild settings." });
  }
});

app.put("/api/guild", requireAdmin, async (req, res) => {
  const { guild_name, guild_uid, region } = req.body || {};
  if (typeof guild_name !== "string" || guild_name.trim().length < 1 || guild_name.length > 50)
    return res.status(400).json({ error: "Guild name must be 1–50 characters." });
  if (typeof guild_uid !== "string" || guild_uid.length > 30)
    return res.status(400).json({ error: "Guild UID must be 0–30 characters." });
  if (typeof region !== "string" || region.length > 30)
    return res.status(400).json({ error: "Region must be 1–30 characters." });

  try {
    const result = await pool.query(
      `UPDATE guild SET guild_name=$1, guild_uid=$2, region=$3, updated_at=NOW()
       WHERE id=1 RETURNING guild_name, guild_uid, region, updated_at`,
      [guild_name.trim(), guild_uid.trim(), region.trim() || "India"]
    );
    res.json(result.rows[0]);
  } catch {
    res.status(500).json({ error: "Could not save guild settings." });
  }
});

app.get("/api/glory", async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit || "30", 10) || 30, 1), 100);
  try {
    const result = await pool.query(
      `SELECT id, member_name, member_uid, glory, note, created_at
       FROM glory_entries ORDER BY created_at DESC LIMIT $1`, [limit]
    );
    const total = await pool.query("SELECT COALESCE(SUM(glory),0)::bigint AS total FROM glory_entries");
    res.json({ entries: result.rows, total_glory: total.rows[0].total });
  } catch {
    res.status(500).json({ error: "Could not load Glory records." });
  }
});

app.post("/api/glory", requireAdmin, async (req, res) => {
  const { member_name, member_uid = "", glory, note = "" } = req.body || {};
  const amount = Number(glory);
  if (typeof member_name !== "string" || !member_name.trim() || member_name.length > 50)
    return res.status(400).json({ error: "Member name is required (max 50 characters)." });
  if (typeof member_uid !== "string" || member_uid.length > 30)
    return res.status(400).json({ error: "Member UID must be 0–30 characters." });
  if (!Number.isSafeInteger(amount) || amount < 0 || amount > 100000000)
    return res.status(400).json({ error: "Glory must be a whole number from 0 to 100,000,000." });
  if (typeof note !== "string" || note.length > 160)
    return res.status(400).json({ error: "Note must be 160 characters or fewer." });

  try {
    const result = await pool.query(
      `INSERT INTO glory_entries (member_name, member_uid, glory, note)
       VALUES ($1,$2,$3,$4)
       RETURNING id, member_name, member_uid, glory, note, created_at`,
      [member_name.trim(), member_uid.trim(), amount, note.trim()]
    );
    res.status(201).json(result.rows[0]);
  } catch {
    res.status(500).json({ error: "Could not save Glory record." });
  }
});

app.use((_req, res) => res.status(404).json({ error: "Route not found." }));

const port = process.env.PORT || 3000;
initDb().then(() => {
  app.listen(port, () => console.log(`LG OW API listening on ${port}`));
}).catch(err => {
  console.error("Database initialization failed:", err.message);
  process.exit(1);
});
